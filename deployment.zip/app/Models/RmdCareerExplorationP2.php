<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RmdCareerExplorationP2 extends Model
{
    //
}
