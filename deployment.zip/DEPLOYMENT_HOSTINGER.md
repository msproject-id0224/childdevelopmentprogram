# Deployment Guide for Hostinger VPS with CloudPanel

This guide focuses on deploying the Child Development Program (CDP) application to a Hostinger VPS managed via **CloudPanel**.

## Prerequisites

-   Hostinger VPS with CloudPanel installed (Select "CloudPanel" image during VPS setup).
-   Domain name pointed to the VPS IP address.
-   Access to CloudPanel Dashboard (usually `https://your-ip:8443`).

## 1. CloudPanel Site Setup

1.  **Log in** to CloudPanel.
2.  Go to **Sites** -> **Add Site**.
3.  Select **Create a Laravel Site**.
4.  **Domain Name**: `your-domain.com`.
5.  **PHP Version**: Select **PHP 8.2**.
6.  **Site User**: Create a user (e.g., `cdp_user`) and password. **Note these credentials.**
7.  Click **Create**.

## 2. Database Setup

1.  Go to **Databases**.
2.  Click **Add Database**.
3.  **Database Name**: `cdp_db` (or your choice).
4.  **Database User**: `cdp_db_user` (or your choice).
5.  **Password**: Generate a strong password.
6.  Click **Create**.

## 3. Connect & Prepare Code

You need to upload your code to the server. Use SFTP or CloudPanel File Manager.

1.  **SSH into the server** (Optional, for running commands)
    ```bash
    ssh cdp_user@your-ip
    ```
    (Or use the File Manager in CloudPanel if you prefer uploading a zip, but Git is better for updates).

2.  **Navigate to the web root**:
    ```bash
    cd /home/cdp_user/htdocs/your-domain.com
    ```
    *(This directory should contain the default CloudPanel index file. You can remove it.)*

3.  **Upload your code**:
    Since Git is not used, upload the project files directly.
    -   **Option A (SFTP)**: Use FileZilla or WinSCP to upload the project files to `/home/cdp_user/htdocs/your-domain.com`.
    -   **Option B (CloudPanel File Manager)**: Compress your project folder (zip), upload it via CloudPanel File Manager, and extract it.
    
    *Ensure hidden files (like `.env.example`) are uploaded if needed.*

## 4. Install Dependencies

1.  **Install PHP Dependencies**:
    ```bash
    composer install --no-dev --optimize-autoloader
    ```

2.  **Install Node.js Dependencies & Build Assets**:
    *CloudPanel usually comes with Node.js. Check version with `node -v`.*
    ```bash
    npm ci
    npm run build
    ```

## 5. Environment Configuration

1.  **Copy .env file**:
    ```bash
    cp .env.production.example .env
    ```

2.  **Edit .env**:
    ```bash
    nano .env
    ```
    Update the following:
    -   `APP_URL=https://your-domain.com`
    -   `DB_DATABASE`, `DB_USERNAME`, `DB_PASSWORD` (from Step 2)
    -   `REDIS_PASSWORD` (if using Redis, check CloudPanel Services)

3.  **Generate Key**:
    ```bash
    php artisan key:generate
    ```

4.  **Run Migrations**:
    ```bash
    php artisan migrate --force
    ```

5.  **Fix Permissions** (Crucial):
    Since you are logged in as the Site User (`cdp_user`), files are owned by you. However, CloudPanel sets the PHP-FPM user to match the Site User, so standard ownership usually works. Just ensure storage is writable.
    ```bash
    chmod -R 775 storage bootstrap/cache
    ```

## 6. Configure Nginx (Vhost)

CloudPanel handles Nginx automatically for Laravel sites, pointing the root to `/public`.
If you need to customize it:
1.  Go to **Sites** -> `your-domain.com` -> **Vhost**.
2.  Ensure the root is:
    ```nginx
    root $VHOST_ROOT/public;
    ```
    *(This is default for "Laravel Site" template)*.

## 7. Queue Workers (Supervisor)

CloudPanel does not have a GUI for Supervisor, but you can install/configure it via SSH (Root user) or use a Cron job (less robust).
**Recommended**: SSH as **Root** to configure Supervisor.

1.  SSH as root: `ssh root@your-ip`
2.  Install Supervisor: `apt install supervisor -y`
3.  Create config: `nano /etc/supervisor/conf.d/cdp-worker.conf`
    ```ini
    [program:cdp-worker]
    process_name=%(program_name)s_%(process_num)02d
    command=php /home/cdp_user/htdocs/your-domain.com/artisan queue:work redis --sleep=3 --tries=3 --max-time=3600
    autostart=true
    autorestart=true
    user=cdp_user
    numprocs=1
    redirect_stderr=true
    stdout_logfile=/home/cdp_user/htdocs/your-domain.com/storage/logs/worker.log
    ```
    *(Replace `cdp_user` and `your-domain.com` with actual values)*.
4.  Start:
    ```bash
    supervisorctl reread
    supervisorctl update
    supervisorctl start cdp-worker:*
    ```

## 8. Scheduler (Cron)

1.  Go to **CloudPanel Dashboard**.
2.  **Cron Jobs** -> **Add Cron Job**.
3.  **User**: `cdp_user`.
4.  **Command**:
    ```bash
    cd /home/cdp_user/htdocs/your-domain.com && /usr/bin/php8.2 artisan schedule:run >> /dev/null 2>&1
    ```
5.  **Frequency**: `* * * * *` (Every Minute).

## 9. SSL Certificate

1.  Go to **Sites** -> `your-domain.com` -> **SSL/TLS**.
2.  Click **Actions** -> **New Let's Encrypt Certificate**.
3.  Click **Create**.

## 10. Deployment Script

For future updates, use the `deploy.sh` script included in the repo.
1.  Make executable: `chmod +x deploy.sh`
2.  Run: `./deploy.sh`

## Verification

1.  Visit `https://your-domain.com`.
2.  Check Logs: `/home/cdp_user/htdocs/your-domain.com/storage/logs/laravel.log`.

